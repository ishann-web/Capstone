window.APP_CONFIG = {
  tmdb: {
    readAccessToken: "paste-free-tmdb-read-token-here",
  },
  supabase: {
    url: "https://your-project.supabase.co",
    anonKey: "paste-your-supabase-anon-key-here",
  },
};
