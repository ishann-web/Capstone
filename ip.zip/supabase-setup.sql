create table if not exists public.media_votes (
  media_type text not null,
  series_key text not null,
  title text not null,
  image_url text,
  meta text,
  votes integer not null default 0,
  updated_at timestamptz not null default timezone('utc', now()),
  primary key (media_type, series_key)
);

create table if not exists public.media_user_votes (
  client_id text not null,
  media_type text not null,
  series_key text not null,
  created_at timestamptz not null default timezone('utc', now()),
  primary key (client_id, media_type, series_key)
);

alter table public.media_votes enable row level security;
alter table public.media_user_votes enable row level security;

drop policy if exists "Public read votes" on public.media_votes;
create policy "Public read votes"
on public.media_votes
for select
to anon
using (true);

create or replace function public.cast_vote(
  p_client_id text,
  p_media_type text,
  p_series_key text,
  p_title text,
  p_image_url text,
  p_meta text
)
returns table(was_inserted boolean, current_votes integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  inserted_rows integer;
begin
  insert into public.media_user_votes (client_id, media_type, series_key)
  values (p_client_id, p_media_type, p_series_key)
  on conflict do nothing;

  get diagnostics inserted_rows = row_count;

  if inserted_rows = 0 then
    return query
    select false, coalesce(
      (
        select v.votes
        from public.media_votes v
        where v.media_type = p_media_type
          and v.series_key = p_series_key
      ),
      0
    );
    return;
  end if;

  insert into public.media_votes (media_type, series_key, title, image_url, meta, votes)
  values (p_media_type, p_series_key, p_title, p_image_url, p_meta, 1)
  on conflict (media_type, series_key)
  do update
    set votes = public.media_votes.votes + 1,
        title = excluded.title,
        image_url = excluded.image_url,
        meta = excluded.meta,
        updated_at = timezone('utc', now());

  return query
  select true, v.votes
  from public.media_votes v
  where v.media_type = p_media_type
    and v.series_key = p_series_key;
end;
$$;

grant usage on schema public to anon;
grant select on public.media_votes to anon;
grant execute on function public.cast_vote(text, text, text, text, text, text) to anon;
